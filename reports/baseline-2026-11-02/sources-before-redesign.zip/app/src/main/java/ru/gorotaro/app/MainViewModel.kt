package ru.gorotaro.app

import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import ru.gorotaro.app.data.Settings
import ru.gorotaro.domain.*
import java.util.UUID
import android.app.Application

@OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
class MainViewModel(application: Application, private val saved: SavedStateHandle) : AndroidViewModel(application) {
    private val app = application as GoroApplication
    val repo = app.repository
    private val settingsStore = app.settings
    val settings = settingsStore.flow.stateIn(viewModelScope, SharingStarted.Eagerly, Settings())
    val route = saved.getStateFlow("route", "home")
    val question = saved.getStateFlow("question", "")
    val optionA = saved.getStateFlow("a", "Сделать")
    val optionB = saved.getStateFlow("b", "Подождать")
    val cards = MutableStateFlow<List<Card>>(emptyList())
    val reading = MutableStateFlow<Reading?>(null)
    val busy = MutableStateFlow(false)
    val error = MutableStateFlow<String?>(null)
    val message = MutableStateFlow<String?>(null)
    val debugReport = MutableStateFlow("")
    val debugPreview = MutableStateFlow<Reading?>(null)
    private var debugPreviewGeneration = 0
    val periodic = MutableStateFlow<Map<Spread, Reading>>(emptyMap())
    val filter = MutableStateFlow<String?>(null)
    val limit = MutableStateFlow(50)
    val search = saved.getStateFlow("historySearch", "")
    val favorites = saved.getStateFlow("favoritesOnly", false)
    val history = combine(filter, limit, search, favorites) { f, l, q, star -> HistoryQuery(f, l, q, star) }
        .flatMapLatest { repo.history(it.spread, it.limit, it.query, it.favorites) }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    private data class HistoryQuery(val spread: String?, val limit: Int, val query: String, val favorites: Boolean)
    fun searchHistory(value: String) { saved["historySearch"] = value.take(240); limit.value = 50 }
    fun favoritesOnly(value: Boolean) { saved["favoritesOnly"] = value; limit.value = 50 }
    init {
        work {
            cards.value = repo.initialize()
            if (route.value == "debug" && !BuildConfig.DEBUG) saved["route"] = "home"
            saved.get<String>("readingId")?.let { reading.value = repo.get(it) }
            if (route.value == "reading" && reading.value == null) saved["route"] = "home"
            refreshPeriods()
            if (route.value == "debug") refreshDebug()
        }
    }
    private fun work(action: suspend () -> Unit) = viewModelScope.launch {
        try { action() } catch (e: Exception) { if (e is kotlinx.coroutines.CancellationException) throw e; error.value = e.message ?: "Не удалось выполнить действие. Попробуйте ещё раз." }
    }
    suspend fun refreshPeriods() { periodic.value = listOf(Spread.DAY, Spread.WEEK, Spread.GENERAL).mapNotNull { s -> repo.current(s)?.let { s to it } }.toMap() }
    fun refresh() = work { refreshPeriods() }
    fun navigate(route: String) {
        if (route == "debug" && !BuildConfig.DEBUG) return
        saved["route"] = route
        if (route == "home") refresh()
        if (route == "debug") { clearDebugPreview(); refreshDebug() }
    }
    fun refreshDebug() {
        if (BuildConfig.DEBUG) work { debugReport.value = repo.debugReport() }
    }
    fun previewDebug(spread: Spread, ids: List<String>, orientations: List<Orientation>, variant: String) {
        if (!BuildConfig.DEBUG) return
        val generation = ++debugPreviewGeneration
        work {
            val result = repo.debugPreview(spread, ids, orientations, variant)
            if (generation == debugPreviewGeneration) debugPreview.value = result
        }
    }
    fun clearDebugPreview() { debugPreviewGeneration++; debugPreview.value = null }
    fun edit(key: String, value: String) { saved[key] = value }
    fun decision() {
        saved["requestId"] = UUID.randomUUID().toString()
        saved["question"] = ""; saved["a"] = "Сделать"; saved["b"] = "Подождать"
        navigate("decision")
    }
    fun general() {
        if (busy.value) return
        saved["requestId"] = UUID.randomUUID().toString()
        draw(Spread.GENERAL)
    }
    fun draw(spread: Spread) {
        if (busy.value || cards.value.isEmpty()) return
        busy.value = true
        work {
            try {
                val request = if (spread == Spread.DECISION || spread == Spread.GENERAL) saved.get<String>("requestId") ?: UUID.randomUUID().toString().also { saved["requestId"] = it } else null
                val r = repo.create(spread, if (BuildConfig.DEBUG) settings.value.mode else "EXACT", request, question.value, optionA.value, optionB.value)
                show(r)
                if (spread == Spread.DAY) revealAll()
                refreshPeriods()
            } finally { busy.value = false }
        }
    }
    private fun show(r: Reading) { reading.value = r; saved["readingId"] = r.id; navigate("reading") }
    fun open(id: String) = work { repo.get(id)?.let(::show) }
    fun reveal(index: Int) = work { reading.value?.let { r -> reading.value = repo.update(r.id) { if (it.canReveal(index)) it.copy(revealed = it.revealed + index) else it } } }
    fun revealAll() = work { reading.value?.let { r -> reading.value = repo.update(r.id) { it.copy(revealed = it.cards.indices.toSet()) } } }
    fun note(id: String, text: String, happened: String? = null, useful: String? = null) = work { reading.value = repo.update(id) { it.copy(note = text.take(4000), happened = happened?.take(4000) ?: it.happened, useful = useful?.take(4000) ?: it.useful) }; message.value = "Заметки сохранены" }
    fun favorite(id: String) = work {
        val updated = repo.update(id) { it.copy(favorite = !it.favorite) }
        if (reading.value?.id == id) reading.value = updated
    }
    val pendingRestore = MutableStateFlow<ByteArray?>(null)
    val restoreCount = MutableStateFlow(0)
    fun prepareRestore(bytes: ByteArray) = work {
        val backup = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            try { HistoryBackupCodec.decode(bytes) } catch (e: Exception) {
                if (e is kotlinx.coroutines.CancellationException) throw e
                throw IllegalArgumentException("Резервная копия повреждена или имеет неподдерживаемый формат", e)
            }
        }
        restoreCount.value = backup.readings.size
        pendingRestore.value = bytes
    }
    fun cancelRestore() { pendingRestore.value = null }
    fun restoreBackup() {
        val bytes = pendingRestore.value ?: return
        if (busy.value) return
        pendingRestore.value = null; busy.value = true
        work { try {
            val (added, skipped) = repo.restore(bytes)
            refreshPeriods(); reading.value?.id?.let { reading.value = repo.get(it) }
            message.value = "Восстановлено: $added. Уже существовали: $skipped"
        } finally { busy.value = false } }
    }
    fun delete(id: String) = work { repo.delete(id); navigate("history"); refreshPeriods() }
    fun setSettings(s: Settings) = work { settingsStore.save(s) }
    fun reset() = work {
        repo.reset(); settingsStore.reset(); reading.value = null; cancelRestore(); clearDebugPreview()
        saved.remove<String>("readingId"); saved.remove<String>("requestId")
        saved["question"] = ""; saved["a"] = "Сделать"; saved["b"] = "Подождать"
        searchHistory(""); favoritesOnly(false); filter.value = null; limit.value = 50
        navigate("home"); refreshPeriods()
    }
    fun importPackage(bytes: ByteArray) = work {
        busy.value = true
        try { ContentImporter(repo.db, getApplication()).import(bytes); message.value = "Пакет проверен и установлен" } finally { busy.value = false }
    }
}
