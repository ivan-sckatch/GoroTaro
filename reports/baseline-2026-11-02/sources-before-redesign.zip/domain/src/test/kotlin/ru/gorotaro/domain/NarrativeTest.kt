package ru.gorotaro.domain

import java.io.File
import kotlinx.serialization.json.Json
import org.junit.Assert.*
import org.junit.Test

class NarrativeTest {
    private val cards = Json.decodeFromString<List<Card>>(File("../app/src/main/assets/cards.json").readText())

    @Test fun actualCorpusHas132DistinctFormulationsAndValidGrammarFields() {
        assertEquals(22, cards.size)
        assertEquals(132, cards.sumOf { c -> Orientation.entries.sumOf { c.narrative(it)!!.variants.size } })
        cards.forEach { card -> Orientation.entries.forEach { o ->
            val n = card.narrative(o)!!
            assertEquals(3,n.variants.toSet().size)
            assertTrue(n.goal.first().isLowerCase()); assertTrue(n.risk.first().isLowerCase())
            assertFalse(n.goal.endsWith('.')); assertFalse(n.risk.endsWith('.'))
        } }
    }

    @Test fun allThreeProfilesUseOrientationSpecificFragmentsAndStayDistinct() {
        Spread.entries.forEach { spread ->
            repeat(22) { offset ->
                val selected = List(spread.positions.size) { cards[(offset + it) % cards.size] }
                repeat(1 shl selected.size) { mask ->
                    val orientations = selected.indices.map { if (mask and (1 shl it) == 0) Orientation.UP else Orientation.REVERSED }
                    val summaries = (0..2).map { profile ->
                        val r = ComposedResolver.resolve(spread, selected, "c${profile + 1}",orientations)
                        selected.forEachIndexed { i,c ->
                            val expected = c.narrative(orientations[i])!!.variants[(profile+i)%3]
                            assertTrue(r.summary.contains(expected))
                            assertTrue(r.summary.contains(c.nameRu))
                            assertTrue(r.positions.getValue(spread.positions[i]).contains(expected))
                        }
                        assertFalse(r.summary.contains("через тему")); assertFalse(r.summary.contains("Посмотрите"))
                        assertTrue(r.summary.length < 4000)
                        r.summary
                    }
                    assertEquals(3,summaries.toSet().size)
                }
            }
        }
    }

    @Test fun synthesisDependsOnEveryPositionAndItsOrientation() {
        listOf(Spread.WEEK, Spread.GENERAL, Spread.DECISION).forEach { spread ->
            val selected = cards.take(3)
            val up = List(3) { Orientation.UP }
            val initial = ComposedResolver.resolve(spread,selected,"c1",up).summary
            repeat(3) { i ->
                val changed = selected.toMutableList().apply { this[i] = cards[10] }
                assertNotEquals(initial,ComposedResolver.resolve(spread,changed,"c1",up).summary)
                val reversed = up.toMutableList().apply { this[i] = Orientation.REVERSED }
                assertNotEquals(initial,ComposedResolver.resolve(spread,selected,"c1",reversed).summary)
            }
        }
    }
    @Test fun practicalActionAndReflectionDependOnWholeSpread() {
        listOf(Spread.WEEK, Spread.GENERAL, Spread.DECISION).forEach { spread ->
            val selected = cards.take(3)
            val initial = ComposedResolver.resolve(spread, selected, "c1")
            selected.forEach { assertTrue(initial.action.contains(it.narrative!!.goal)) }
            repeat(3) { index ->
                val changed = selected.toMutableList().also { it[index] = cards[9] }
                assertNotEquals(initial.action, ComposedResolver.resolve(spread, changed, "c1").action)
                val orientations = List(3) { if (it == index) Orientation.REVERSED else Orientation.UP }
                assertNotEquals(initial.action, ComposedResolver.resolve(spread, selected, "c1", orientations).action)
            }
            val rendered = initial.render("Учиться", "Работать")
            assertFalse(rendered.action.contains("{option")); assertFalse(rendered.reflection.contains("{option"))
        }
    }

    @Test fun synthesisConnectsDifferentRolesInsteadOfChoosingDecisionForUser() {
        val selected = listOf(cards[1],cards[9],cards[19])
        val week = ComposedResolver.resolve(Spread.WEEK,selected,"c1").summary
        assertTrue(week.contains("Активность здесь встречается с потребностью в паузе"))
        assertTrue(week.contains("Чтобы ${selected[0].narrative!!.goal}"))
        assertTrue(week.contains(selected[1].narrative!!.risk))
        assertTrue(week.contains("чтобы ${selected[2].narrative!!.goal}"))
        val decision = ComposedResolver.resolve(Spread.DECISION,selected,"c2").render("Учиться", "Работать").summary
        assertTrue(decision.contains("Учиться")); assertTrue(decision.contains("Работать"))
        assertFalse(decision.contains("{option"))
        assertTrue(decision.contains("Перед выбором важно ${selected[2].narrative!!.goal}"))
        val general = ComposedResolver.resolve(Spread.GENERAL,selected,"c3").summary
        assertTrue(general.contains("используйте прошлый опыт")); assertTrue(general.contains("в настоящем важно"))
        writeRepresentativeExamplesForEditorialReview()
    }

    @Test fun incompleteBankFailsRatherThanProducingGenericText() {
        val c = cards[0].copy(narrative = null)
        assertThrows(IllegalArgumentException::class.java) { ComposedResolver.resolve(Spread.DAY,listOf(c),"c1") }
        assertThrows(IllegalArgumentException::class.java) { ComposedResolver.resolve(Spread.WEEK,cards.take(1),"c1") }
    }

    @Test fun everyPacePairCanBeConnectedWithoutLosingCardContent() {
        NarrativePace.entries.forEach { a -> NarrativePace.entries.forEach { b ->
            val selected = cards.take(3).mapIndexed { i,c -> c.copy(narrative = c.narrative!!.copy(pace = if (i == 0) a else b)) }
            val summary = ComposedResolver.resolve(Spread.WEEK,selected,"c1").summary
            selected.forEach { assertTrue(summary.contains(it.nameRu)) }
            assertTrue(summary.contains("Чтобы ${selected[0].narrative!!.goal}"))
        } }
    }
    private fun writeRepresentativeExamplesForEditorialReview() {
        val selected = listOf(cards[1],cards[9],cards[19])
        val output = File("../reports/NARRATIVE-EXAMPLES.md")
        output.writeText("# Примеры связного толкования\n\nЭто фиксированные примеры из базы, не персональный расклад.\n\n" +
            Spread.entries.joinToString("\n\n") { spread ->
                val draw = selected.take(spread.positions.size)
                val orientations = draw.indices.map { if (it == 1) Orientation.REVERSED else Orientation.UP }
                "## ${spread.title}\n\n" + ComposedResolver.resolve(spread,draw,"c2",orientations).render("Учиться", "Работать").summary
            } + "\n")
    }
}
