package ru.gorotaro.domain

/** Complete sentences and infinitive goals form a stable grammar contract for the local corpus. */
internal object NarrativeComposer {
    private fun theme(n: List<Narrative>): String {
        val counts = n.groupingBy { it.pace }.eachCount()
        val dominant = counts.maxBy { it.value }.key
        val subject = when (dominant) {
            NarrativePace.MOVE -> "переход от намерения к посильному действию"
            NarrativePace.PAUSE -> "прояснение условий перед следующим шагом"
            NarrativePace.STRUCTURE -> "поиск опоры в понятных правилах и границах"
            NarrativePace.CONNECT -> "согласование собственных потребностей с взаимностью"
            NarrativePace.CHANGE -> "пересмотр привычного способа и сохранение полезных опор"
        }
        return if (counts.size == 1) "Все карты усиливают одну тему — $subject."
        else if (counts.getValue(dominant) >= 2) "Повторяющаяся тема расклада — $subject; другая карта уточняет условия этого движения."
        else "Карты показывают разные стороны одной задачи: ${n.joinToString("; ") { it.goal }}. Их полезно согласовать в одном посильном шаге."
    }

    private fun approach(n: List<Narrative>): String {
        val paces = n.map { it.pace }.toSet()
        return when {
            NarrativePace.MOVE in paces && NarrativePace.PAUSE in paces -> "Сначала уточните один неизвестный факт, затем проверьте решение небольшим обратимым действием."
            NarrativePace.STRUCTURE in paces && NarrativePace.CHANGE in paces -> "Выберите одну привычку или договорённость для пересмотра, заранее определив, какую опору сохраните."
            NarrativePace.CONNECT in paces && NarrativePace.STRUCTURE in paces -> "Обсудите одну конкретную договорённость: что вы готовы сделать и где проходит ваша граница."
            NarrativePace.CONNECT in paces && NarrativePace.PAUSE in paces -> "Назовите, что нужно обдумать самостоятельно, и договоритесь, когда вернётесь к разговору."
            NarrativePace.CHANGE in paces -> "Проверьте один новый способ в небольшом масштабе и запишите, по какому признаку оцените результат."
            NarrativePace.MOVE in paces -> "Выберите одно действие, которое можете завершить сегодня, и определите признак его завершения."
            NarrativePace.STRUCTURE in paces -> "Запишите одно правило или ограничение, которое поможет вам довести следующий шаг до конца."
            NarrativePace.CONNECT in paces -> "Сформулируйте одну просьбу или предложение и уточните, устраивает ли оно обе стороны."
            else -> "Запишите один вопрос, на который нужна ясность, и определите, где найдёте ответ."
        }
    }

    fun action(spread: Spread, cards: List<Card>, orientations: List<Orientation>, n: List<Narrative>): String = when (spread) {
        Spread.DAY -> cards[0].action(orientations[0])
        Spread.WEEK -> "Чтобы ${n[0].goal}, учтите условие «${n[1].goal}» и проверьте препятствие: ${n[1].risk}. ${approach(n)} Используйте ресурс последней карты: ${cards[2].action(orientations[2])} Свяжите этот шаг с задачей «${n[2].goal}»."
        Spread.GENERAL -> "Отметьте, что из прошлого помогает ${n[0].goal}, а что стоит пересмотреть. Для настоящего выберите задачу «${n[1].goal}». ${approach(n)} Направление следующего шага — ${n[2].goal}: ${cards[2].action(orientations[2])}"
        Spread.DECISION -> "Составьте две строки: «{optionA}» — ${n[0].goal}, риск: ${n[0].risk}; «{optionB}» — ${n[1].goal}, риск: ${n[1].risk}. Для обоих путей выполните одну проверку: ${cards[2].action(orientations[2])} Её задача — ${n[2].goal}. Сравните факты и выберите приемлемые для вас условия."
    }

    fun reflection(spread: Spread, n: List<Narrative>, day: String): String = when (spread) {
        Spread.DAY -> day
        Spread.WEEK -> "Какой небольшой шаг поможет ${n[0].goal}, если учесть, что ${n[1].risk}, и использовать возможность ${n[2].goal}?"
        Spread.GENERAL -> "Что из прошлого вы сохраните для задачи «${n[1].goal}» и по какому признаку поймёте, что следующий шаг помогает ${n[2].goal}?"
        Spread.DECISION -> "Какой факт после проверки «${n[2].goal}» изменит ваше сравнение «{optionA}» и «{optionB}»? С каким риском вы готовы работать?"
    }
    private fun relation(a: Narrative, b: Narrative): String = when {
        a.pace == NarrativePace.MOVE && b.pace == NarrativePace.PAUSE ->
            "Активность здесь встречается с потребностью в паузе: темп решения стоит согласовать с ясностью условий."
        a.pace == NarrativePace.PAUSE && b.pace == NarrativePace.MOVE ->
            "Размышление и действие дополняют друг друга: понимание стоит закрепить посильным шагом, сохраняя время для проверки."
        setOf(a.pace, b.pace) == setOf(NarrativePace.STRUCTURE, NarrativePace.CHANGE) ->
            "Между этими картами возникает напряжение устойчивости и перемен: полезно сохранить надёжную основу, пересматривая то, что перестало работать."
        a.pace == NarrativePace.CONNECT && b.pace == NarrativePace.STRUCTURE || a.pace == NarrativePace.STRUCTURE && b.pace == NarrativePace.CONNECT ->
            "Здесь забота и договорённости поддерживают друг друга: ясные границы помогают сохранить взаимность без лишнего давления."
        a.pace == NarrativePace.CHANGE && b.pace == NarrativePace.PAUSE || a.pace == NarrativePace.PAUSE && b.pace == NarrativePace.CHANGE ->
            "Перемены и переосмысление связаны: пауза может помочь выбрать, что сохранить, а что постепенно отпустить."
        a.pace == NarrativePace.MOVE && b.pace == NarrativePace.CONNECT ->
            "Инициативу важно поддержать контактом: самостоятельное действие становится устойчивее, когда остаётся место для обратной связи и взаимности."
        a.pace == NarrativePace.CONNECT && b.pace == NarrativePace.MOVE ->
            "Контакт получает продолжение в действии: ясный шаг помогает закрепить договорённость и сделать поддержку ощутимой."
        setOf(a.pace, b.pace) == setOf(NarrativePace.MOVE, NarrativePace.STRUCTURE) ->
            "Энергии действия нужна опора в ясных условиях: правила и распределение ответственности помогут довести начатое до результата."
        setOf(a.pace, b.pace) == setOf(NarrativePace.CONNECT, NarrativePace.PAUSE) ->
            "Личные размышления и контакт требуют равновесия: время на себя не должно исключать взаимную поддержку."
        setOf(a.pace, b.pace) == setOf(NarrativePace.MOVE, NarrativePace.CHANGE) ->
            "Действие и перемены связаны готовностью менять способ: продолжайте движение, проверяя, подходит ли прежний план новым условиям."
        setOf(a.pace, b.pace) == setOf(NarrativePace.CONNECT, NarrativePace.CHANGE) ->
            "Перемены затрагивают и отношения: обновляя условия, сохраняйте уважение к потребностям и границам участников."
        setOf(a.pace, b.pace) == setOf(NarrativePace.STRUCTURE, NarrativePace.PAUSE) ->
            "Правила полезно проверить в спокойной паузе: так легче отличить надёжную опору от привычки, которая больше не помогает."
        a.pace == b.pace -> when (a.pace) {
            NarrativePace.MOVE -> "Обе карты усиливают тему действия; полезно собрать энергию в одном направлении, сохраняя реалистичный темп."
            NarrativePace.PAUSE -> "Обе карты подчёркивают необходимость осмысления; чтобы пауза не стала застоем, определите, какой вопрос она должна прояснить."
            NarrativePace.STRUCTURE -> "Обе карты связывают устойчивость с ясными условиями; договорённости должны поддерживать результат, оставляя место для гибкости."
            NarrativePace.CONNECT -> "В обеих картах важна взаимность; забота и сотрудничество устойчивы, когда потребности участников названы прямо."
            NarrativePace.CHANGE -> "Обе карты выделяют переход; сначала определите, что уже исчерпано, и сохраните опоры, которые пригодятся на новом этапе."
        }
        else -> error("Не описана связь характеров действия")
    }

    fun compose(spread: Spread, cards: List<Card>, orientations: List<Orientation>, n: List<Narrative>, text: List<String>, variant: Int): String {
        fun card(i: Int, capital: Boolean = false) = "${if (capital) "Карта" else "карта"} «${cards[i].nameRu}»" + if (orientations[i] == Orientation.REVERSED) " в перевёрнутом положении" else ""
        val narrative = when (spread) {
            Spread.DAY -> listOf(
                "Сегодня ${card(0)} выделяет главную задачу: ${n[0].goal}. ${text[0]} Важно учесть, что ${n[0].risk}.",
                "${card(0, true)} связывает сегодняшний день с задачей: ${n[0].goal}. ${text[0]} Уязвимое место — то, что ${n[0].risk}.",
                "Смысл дня — ${n[0].goal}. ${card(0, true)} уточняет эту задачу: ${text[0]} Сохраните внимание к риску: ${n[0].risk}."
            )[variant]

            Spread.WEEK -> {
                val opening = listOf("Главный фокус недели", "В центре недели", "Основная задача недели")[variant]
                "$opening — ${n[0].goal}. ${card(0, true)}: ${text[0]}\n\n" +
                    "${card(1, true)} уточняет возможное затруднение: ${text[1]} В этой позиции важно учесть, что ${n[1].risk}. ${relation(n[0], n[1])}\n\n" +
                    "${card(2, true)} связывает это напряжение с действием: ${text[2]} Чтобы ${n[0].goal}, начните с того, чтобы ${n[2].goal}. ${relation(n[1], n[2])}"
            }

            Spread.GENERAL -> {
                val opening = listOf("О прошлом опыте говорит", "Истоки ситуации раскрывает", "Влияние прошлого обозначает")[variant]
                "$opening ${card(0)}. ${text[0]} Задача этого этапа — ${n[0].goal}.\n\n" +
                    "Сейчас ${card(1)} переносит внимание на следующую задачу: ${n[1].goal}. ${text[1]} ${relation(n[0], n[1])}\n\n" +
                    "Возможное дальнейшее направление обозначает ${card(2)}: ${text[2]} ${relation(n[1], n[2])} " +
                    "Общий вывод: используйте прошлый опыт, чтобы ${n[0].goal}; в настоящем важно ${n[1].goal}, а следующий шаг — ${n[2].goal}. Этот путь зависит от ваших решений и меняющихся условий."
            }

            Spread.DECISION -> {
                val opening = listOf("Два варианта отличаются задачами", "В выборе важны разные условия", "Сравнение показывает две разные задачи")[variant]
                "$opening. Для «{optionA}» задача — ${n[0].goal}: ${card(0)}. ${text[0]} Здесь важно учесть, что ${n[0].risk}.\n\n" +
                    "Для «{optionB}» задача — ${n[1].goal}: ${card(1)}. ${text[1]} Уязвимое место этого пути — то, что ${n[1].risk}. ${relation(n[0], n[1])}\n\n" +
                    "Оба пути соединяет проверка, которую обозначает ${card(2)}: ${text[2]} Перед выбором важно ${n[2].goal}. " +
                    "Для «{optionA}» соотнесите эту проверку с задачей «${n[0].goal}», для «{optionB}» — с задачей «${n[1].goal}». Предпочтение отдайте пути, условия и последствия которого лучше согласуются с вашими приоритетами."
            }
        }
        if (spread == Spread.DAY) return narrative
        val bridge = when (spread) {
            Spread.WEEK -> "Как действие поддерживает фокус недели: ${relation(n[0], n[2])} При этом проверьте ограничение: ${n[1].risk}."
            Spread.GENERAL -> "Связь начала и возможного продолжения: ${relation(n[0], n[2])} Настоящее служит переходом между ними: важно ${n[1].goal}, учитывая, что ${n[1].risk}."
            Spread.DECISION -> "Проверка пути «{optionA}»: ${relation(n[0], n[2])} Проверка пути «{optionB}»: ${relation(n[1], n[2])} Общий критерий — ${n[2].goal}; обратите внимание, что ${n[2].risk}."
            Spread.DAY -> error("Одна карта не требует связки")
        }
        return "${theme(n)}\n\n$narrative\n\n$bridge\n\n${approach(n)}"
    }
}
